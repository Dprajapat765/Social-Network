<?php 
include('includes/header.php');
#session_destroy();

?>



			

			<div class="main_column column">
				This is a profile page

			</div>
		</div>
	</div>


</body>
</html>
