<?php 
# create database
$con = mysqli_connect("localhost","root","","rural_network");
if ($con) {
	echo "Database created";
}
else{
	echo "Failed to create database".mysqli_error();
}



// creating user table in sql

$query = mysqli_query($con,"CREATE TABLE users(
id VARCHAR(10),
first_name VARCHAR(25),
last_name VARCHAR(25),
username VARCHAR(100),
email VARCHAR(100),
email_status VARCHAR(3),
date_of_birth DATE,
password VARCHAR(255),
profile_pic VARCHAR(255),
num_post VARCHAR(10),
num_likes VARCHAR(10),
user_closed VARCHAR(3),
friend_array TEXT,
signup_date DATE);");

if ($query) {
	echo "<br>USER table created<br>";
}
else{
	echo "<br><br>USER table already exist!".mysqli_error($con);
}


/*post home page table*/


$query2 = mysqli_query($con,"CREATE TABLE posts ( 
id INT,
body TEXT, 
added_by VARCHAR(60), 
user_to VARCHAR(60), 
date_added DATETIME, 
user_closed VARCHAR(3), 
deleted VARCHAR(3), 
likes INT, 
PRIMARY KEY (id))");

if ($query2) {
	echo "<br>POST table created<br>";
}
else{
	echo "<br><br>POST table already exist!".mysqli_error($con);
}


/*comment table */

$query3 = mysqli_query($con,"CREATE TABLE posts_comments ( 
id INT,
post_body TEXT, 
posted_by VARCHAR(60), 
posted_to VARCHAR(60), 
date_added DATETIME, 
removed VARCHAR(3), 
post_id INT, 
PRIMARY KEY (id))");

if ($query3) {
	echo "<br>POST_COMMENTS table created<br>";
}
else{
	echo "<br><br>POST_COMMENTS table already exist!".mysqli_error($con);
}


/*likes table */
$query4 = mysqli_query($con,"CREATE TABLE likes ( 
id INT,
username VARCHAR(60), 
post_id INT,
PRIMARY KEY (id))");

if ($query4) {
	echo "<br>LIKES table created<br>";
}
else{
	echo "<br><br>LIKES table already exist!".mysqli_error($con);
}



?>
